"""
LangChain create_agent() 기반 무인 점포 AI 에이전트 (v1.0 스타일)
"""

from langchain.agents import create_agent
from langchain_core.tools import tool
from typing import List
from dotenv import load_dotenv

from vision_core import analyze_video_picks, process_frame_realtime
from product_db import get_price, get_all_products

# 환경 변수 로드 (명시적 경로 지정)
load_dotenv("C:/env/.env")

# 전역 장바구니 (세션 상태와 동기화를 위해 사용)
# 실제 장바구니는 st.session_state.cart에 저장됨
cart = []


@tool
def analyze_video(video_path: str) -> str:
    """
    영상 분석 → Pick된 상품 감지
    
    Args:
        video_path: 분석할 영상 파일 경로
        
    Returns:
        감지된 상품 정보 문자열
    """
    try:
        picks = analyze_video_picks(video_path)
        
        if not picks:
            return "No product picked detected in the video."
        
        # 중복 제거하면서 순서 유지
        unique_picks = []
        for pick in picks:
            if pick not in unique_picks:
                unique_picks.append(pick)
        
        return f"Detected picks: {', '.join(unique_picks)}"
    except Exception as e:
        return f"Error analyzing video: {str(e)}"


@tool
def add_to_cart(product: str) -> str:
    """
    장바구니에 상품 추가
    
    Args:
        product: 추가할 상품 이름
        
    Returns:
        추가 결과 메시지
    """
    global cart
    
    valid_products = get_all_products()
    if product not in valid_products:
        return f"Invalid product: {product}. Available products: {', '.join(valid_products)}"
    
    cart.append(product)
    price = get_price(product)
    return f"{product} (₩{price:,}) added to cart. Cart now has {len(cart)} items."


@tool
def get_cart_total() -> str:
    """
    장바구니 총액 계산
    
    Returns:
        총액 정보 문자열
    """
    global cart
    
    if not cart:
        return "Cart is empty. Total: ₩0"
    
    total = sum(get_price(p) for p in cart)
    items_summary = {}
    for item in cart:
        items_summary[item] = items_summary.get(item, 0) + 1
    
    summary_lines = [f"{name} x{count} (₩{get_price(name):,} each)" 
                     for name, count in items_summary.items()]
    
    return f"Cart Items:\n" + "\n".join(summary_lines) + f"\n\nTotal: ₩{total:,}"


@tool
def clear_cart() -> str:
    """
    장바구니 비우기
    
    Returns:
        확인 메시지
    """
    global cart
    cart.clear()
    
    # Streamlit 세션 상태도 비우기 (가능한 경우)
    try:
        import streamlit as st
        if 'cart' in st.session_state:
            st.session_state.cart.clear()
    except:
        pass
    
    return "Cart cleared."


@tool
def get_cart_items() -> str:
    """
    장바구니에 담긴 상품 목록 조회
    
    Returns:
        상품 목록 문자열
    """
    global cart
    
    if not cart:
        return "Cart is empty."
    
    items_count = {}
    for item in cart:
        items_count[item] = items_count.get(item, 0) + 1
    
    items_list = [f"{name} x{count}" for name, count in items_count.items()]
    return f"Cart items: {', '.join(items_list)}"


# 에이전트에 사용할 도구들
tools = [analyze_video, add_to_cart, get_cart_total, clear_cart, get_cart_items]

# 시스템 프롬프트 생성
products_list = ", ".join(get_all_products())
system_prompt = f"""You are an AI agent for an unmanned store (like Amazon Go). 
Your role is to:
1. Analyze video footage to detect when customers pick up products
2. Automatically add picked products to the shopping cart
3. Calculate the total price

Available products: {products_list}

When you detect products from video analysis, automatically add them to the cart using add_to_cart tool.
After analyzing a video, always add all detected products to the cart automatically."""

# LangChain v1.0 create_agent()로 에이전트 생성
agent = create_agent(
    model="gpt-4o",
    tools=tools,
    system_prompt=system_prompt
)


def run_agent(prompt: str) -> str:
    """
    에이전트 실행 (LangChain v1.0 스타일)
    
    Args:
        prompt: 사용자 입력 프롬프트
        
    Returns:
        에이전트 응답
    """
    try:
        # LangChain v1.0 스타일: messages 형식 사용
        result = agent.invoke({
            "messages": [
                {"role": "user", "content": prompt}
            ]
        })
        
        # 응답 추출
        if "messages" in result and result["messages"]:
            # 마지막 메시지에서 content 추출
            last_message = result["messages"][-1]
            if hasattr(last_message, 'content'):
                return last_message.content
            elif isinstance(last_message, dict) and 'content' in last_message:
                return last_message['content']
            else:
                return str(last_message)
        elif "output" in result:
            return result["output"]
        else:
            return str(result)
    except Exception as e:
        return f"Agent execution error: {str(e)}"


def get_cart() -> List[str]:
    """
    현재 장바구니 내용 반환 (내부 사용)
    
    Returns:
        장바구니 상품 리스트
    """
    # Streamlit 세션 상태에서 가져오기 (가능한 경우)
    try:
        import streamlit as st
        if 'cart' in st.session_state:
            return st.session_state.cart.copy()
    except:
        pass
    
    # Streamlit이 없는 환경에서는 전역 변수 사용
    return cart.copy()


def add_product_to_cart(product: str) -> str:
    """
    장바구니에 상품 추가 (직접 호출용 헬퍼 함수)
    
    Args:
        product: 추가할 상품 이름
        
    Returns:
        추가 결과 메시지
    """
    global cart
    
    valid_products = get_all_products()
    if product not in valid_products:
        return f"Invalid product: {product}. Available products: {', '.join(valid_products)}"
    
    # Streamlit 세션 상태에 저장 (가능한 경우)
    try:
        import streamlit as st
        if 'cart' not in st.session_state:
            st.session_state.cart = []
        # 중복 체크: 이미 장바구니에 있는지 확인 (선택사항 - 중복 허용하려면 제거)
        # 여기서는 중복 허용하지만, 실제로는 한 번만 추가되어야 함
        st.session_state.cart.append(product)
        # 전역 변수도 동기화
        cart.append(product)
    except:
        # Streamlit이 없는 환경에서는 전역 변수만 사용
        cart.append(product)
    
    price = get_price(product)
    
    # 장바구니 크기 계산
    try:
        import streamlit as st
        cart_size = len(st.session_state.cart) if 'cart' in st.session_state else len(cart)
    except:
        cart_size = len(cart)
    
    return f"{product} (₩{price:,}) added to cart. Cart now has {cart_size} items."

