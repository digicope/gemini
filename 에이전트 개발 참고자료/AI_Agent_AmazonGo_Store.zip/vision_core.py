"""
영상 처리 핵심 로직: 프레임 추출, 제품 직접 인식, Pick/Put 판정
"""

import cv2
import base64
import numpy as np
from typing import List, Tuple, Optional
from openai import OpenAI
from dotenv import load_dotenv
import os
import re

from product_db import PRODUCTS, get_product_names_en, get_all_products

# 환경 변수 로드 (명시적 경로 지정)
load_dotenv("C:/env/.env")

# OpenAI 클라이언트 초기화
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError("OPENAI_API_KEY environment variable is not set. Please check your .env file at C:/env/.env")
client = OpenAI(api_key=api_key)


def extract_frames(video_path: str, skip: int = 5) -> List[np.ndarray]:
    """
    영상 파일에서 프레임 추출
    
    Args:
        video_path: 영상 파일 경로
        skip: 프레임 추출 간격 (기본값: 5프레임마다 1개)
        
    Returns:
        추출된 프레임 리스트
    """
    cap = cv2.VideoCapture(video_path)
    frames = []
    count = 0
    
    if not cap.isOpened():
        print(f"영상 파일을 열 수 없습니다: {video_path}")
        return frames
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        if count % skip == 0:
            frames.append(frame.copy())
        
        count += 1
    
    cap.release()
    return frames


def frame_to_base64(frame: np.ndarray) -> str:
    """
    OpenCV 프레임을 base64 문자열로 변환
    
    Args:
        frame: OpenCV 이미지 프레임
        
    Returns:
        base64 인코딩된 문자열
    """
    _, buffer = cv2.imencode(".jpg", frame)
    img_base64 = base64.b64encode(buffer).decode("utf-8")
    return img_base64


def detect_products_in_image(frame: np.ndarray) -> List[str]:
    """
    Vision API를 사용하여 이미지에서 제품을 직접 인식
    
    Args:
        frame: OpenCV 이미지 프레임
        
    Returns:
        인식된 제품 이름 리스트
    """
    try:
        # 프레임을 base64로 변환
        img_base64 = frame_to_base64(frame)
        
        # 사용 가능한 제품 목록 생성
        available_products = get_all_products()
        product_list_text = ", ".join(available_products)
        
        # 각 제품의 인식 가능한 이름 리스트 생성
        product_descriptions = []
        for product in available_products:
            names = get_product_names_en(product)
            product_descriptions.append(f"{product}: {', '.join(names)}")
        
        products_description = "\n".join(product_descriptions)
        
        # Vision API 호출
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": "You are a product recognition assistant for an unmanned store. Analyze images and identify products from the available list. Return product names separated by commas if multiple products are detected, or 'none' if no products are found."
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": f"""Analyze this image and identify which products are visible from the following list:
                            
Available products: {product_list_text}

Product recognition names:
{products_description}

Important: 
- Only return the product names from the available list (e.g., cola, water, sandwich, eye_drop, pen, charger, toothpaste)
- If a person is picking up or holding a product, identify that product
- Return multiple product names separated by commas if multiple products are visible
- Return 'none' if no products from the list are detected
- Focus on products that are being picked up or held by hands
- For toothpaste, recognize it even if it's in a tube form (tube toothpaste, toothpaste tube)
- For water, recognize it as "water" even if it's labeled as "500ml", "500ml water", "bottled water", "mineral water", or any water bottle
- Be flexible with product recognition - if you see something that matches the description, return the product name
- When you see a water bottle (any size, any brand, labeled 500ml or not), return "water"

Return format: product_name1, product_name2 or 'none'"""
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{img_base64}"
                            }
                        }
                    ]
                }
            ],
            max_tokens=200
        )
        
        text = response.choices[0].message.content.strip().lower()
        
        # "none" 체크
        if "none" in text or "not found" in text or "no product" in text:
            return []
        
        # 사용 가능한 제품 목록
        valid_products = set(available_products)
        detected_products = []
        
        # 쉼표로 분리하고 각 제품 확인
        parts = [p.strip() for p in text.split(",")]
        
        for part in parts:
            # 직접 매칭 확인
            if part in valid_products:
                detected_products.append(part)
            else:
                # 부분 문자열 매칭 확인 (예: "cola bottle" -> "cola")
                for product in valid_products:
                    if product in part or part in product:
                        if product not in detected_products:
                            detected_products.append(product)
                            break
        
        # 중복 제거
        return list(set(detected_products))
        
    except Exception as e:
        print(f"제품 인식 중 오류 발생: {e}")
        return []


def analyze_video_picks(video_path: str) -> List[str]:
    """
    영상 전체를 분석하여 Pick된 상품 리스트 반환
    
    Args:
        video_path: 영상 파일 경로
        
    Returns:
        Pick된 상품 이름 리스트
    """
    frames = extract_frames(video_path, skip=5)
    
    if not frames:
        return []
    
    picks = []
    prev_products = set()
    
    for i, frame in enumerate(frames):
        # 현재 프레임에서 제품 인식
        current_products = set(detect_products_in_image(frame))
        
        # 이전 프레임에는 없었고 현재 프레임에 있는 제품 = 새로 등장한 제품 (Pick 가능)
        new_products = current_products - prev_products
        
        # 이전 프레임에는 있었고 현재 프레임에는 없는 제품 = 사라진 제품 (Pick 확정)
        disappeared_products = prev_products - current_products
        
        # 사라진 제품을 Pick으로 판정
        for product in disappeared_products:
            if product not in picks:
                picks.append(product)
        
        prev_products = current_products
    
    return picks


def process_frame_realtime(
    frame: np.ndarray,
    prev_products: Optional[List[str]] = None
) -> Tuple[List[str], List[str]]:
    """
    실시간 프레임 처리: 제품 직접 인식
    
    Args:
        frame: OpenCV 이미지 프레임 (numpy array)
        prev_products: 이전 프레임에서 인식된 제품 리스트
        
    Returns:
        (new_products, pick_products) 튜플
        - new_products: 현재 프레임에서 인식된 제품 리스트
        - pick_products: Pick된 제품 리스트 (이전에 있었고 현재는 없음)
    """
    if prev_products is None:
        prev_products = []
    
    # 현재 프레임에서 제품 인식
    current_products = detect_products_in_image(frame)
    
    # 이전 프레임의 제품 집합
    prev_products_set = set(prev_products)
    current_products_set = set(current_products)
    
    # Pick 판정: 이전 프레임에는 있었고 현재 프레임에는 없는 제품 = Pick
    pick_products = list(prev_products_set - current_products_set)
    
    return current_products, pick_products


def image_bytes_to_frame(image_bytes: bytes) -> np.ndarray:
    """
    이미지 바이트 데이터를 OpenCV 프레임으로 변환
    
    Args:
        image_bytes: 이미지 바이트 데이터
        
    Returns:
        OpenCV 이미지 프레임 (numpy array)
    """
    import io
    from PIL import Image
    
    # PIL Image로 변환
    image = Image.open(io.BytesIO(image_bytes))
    
    # RGB로 변환 (OpenCV는 BGR 사용)
    if image.mode != 'RGB':
        image = image.convert('RGB')
    
    # numpy array로 변환
    frame = np.array(image)
    
    # BGR로 변환 (OpenCV 형식)
    frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
    
    return frame
