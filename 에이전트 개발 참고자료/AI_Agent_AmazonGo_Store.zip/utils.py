"""
유틸리티 함수: 프레임 변환, 디버그 함수 등
"""

import cv2
import numpy as np
from typing import List, Tuple
import os


def draw_bbox_on_frame(
    frame: np.ndarray,
    bbox: Tuple[int, int, int, int],
    label: str = "",
    color: Tuple[int, int, int] = (0, 255, 0)
) -> np.ndarray:
    """
    프레임에 bbox 그리기
    
    Args:
        frame: OpenCV 이미지 프레임
        bbox: (x1, y1, x2, y2)
        label: bbox에 표시할 레이블
        color: bbox 색상 (B, G, R)
        
    Returns:
        bbox가 그려진 프레임
    """
    x1, y1, x2, y2 = bbox
    frame_copy = frame.copy()
    
    # bbox 그리기
    cv2.rectangle(frame_copy, (x1, y1), (x2, y2), color, 2)
    
    # 레이블 추가
    if label:
        cv2.putText(
            frame_copy,
            label,
            (x1, y1 - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            color,
            2
        )
    
    return frame_copy


def draw_shelf_zones(frame: np.ndarray, shelf_zones: dict) -> np.ndarray:
    """
    프레임에 선반 영역 그리기
    
    Args:
        frame: OpenCV 이미지 프레임
        shelf_zones: 선반 영역 딕셔너리 {상품명: (x1, y1, x2, y2)}
        
    Returns:
        선반 영역이 그려진 프레임
    """
    frame_copy = frame.copy()
    
    colors = [
        (255, 0, 0),    # 파란색
        (0, 255, 0),    # 초록색
        (0, 0, 255),    # 빨간색
        (255, 255, 0),  # 청록색
    ]
    
    for idx, (product, zone) in enumerate(shelf_zones.items()):
        color = colors[idx % len(colors)]
        x1, y1, x2, y2 = zone
        
        # 선반 영역 그리기
        cv2.rectangle(frame_copy, (x1, y1), (x2, y2), color, 2)
        
        # 상품 이름 표시
        cv2.putText(
            frame_copy,
            product,
            (x1, y1 - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            color,
            2
        )
    
    return frame_copy


def save_frame(frame: np.ndarray, filepath: str):
    """
    프레임을 파일로 저장
    
    Args:
        frame: OpenCV 이미지 프레임
        filepath: 저장할 파일 경로
    """
    cv2.imwrite(filepath, frame)


def resize_frame(frame: np.ndarray, max_width: int = 800) -> np.ndarray:
    """
    프레임 크기 조정 (비율 유지)
    
    Args:
        frame: OpenCV 이미지 프레임
        max_width: 최대 너비
        
    Returns:
        크기 조정된 프레임
    """
    height, width = frame.shape[:2]
    
    if width <= max_width:
        return frame
    
    ratio = max_width / width
    new_width = max_width
    new_height = int(height * ratio)
    
    return cv2.resize(frame, (new_width, new_height))


def frames_to_video(
    frames: List[np.ndarray],
    output_path: str,
    fps: int = 30
):
    """
    프레임 리스트를 영상 파일로 저장
    
    Args:
        frames: 프레임 리스트
        output_path: 출력 영상 파일 경로
        fps: 초당 프레임 수
    """
    if not frames:
        return
    
    height, width = frames[0].shape[:2]
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    
    for frame in frames:
        out.write(frame)
    
    out.release()


def create_output_dir(dirname: str = "output"):
    """
    출력 디렉토리 생성
    
    Args:
        dirname: 디렉토리 이름
    """
    if not os.path.exists(dirname):
        os.makedirs(dirname)

