"""
이미지 분석 도구
Google Gemini API를 사용하여 여행 사진을 분석하고 장소를 추론
"""

import base64
from pathlib import Path
from typing import Optional
from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
from dotenv import load_dotenv
import os
from utils.logger import logger

# 환경 변수 로드
load_dotenv("C:/env/.env")

# LLM 인스턴스 캐시
_llm_instance = None


def _get_llm():
    """LLM 인스턴스를 지연 초기화하여 반환"""
    global _llm_instance
    if _llm_instance is None:
        _llm_instance = ChatGoogleGenerativeAI(
            model="gemini-2.5-flash",
            google_api_key=os.getenv("GOOGLE_API_KEY"),
            temperature=0.7
        )
    return _llm_instance


def encode_image(image_path: str) -> str:
    """
    이미지 파일을 base64로 인코딩
    
    Args:
        image_path: 이미지 파일 경로
    
    Returns:
        base64 인코딩된 이미지 문자열
    """
    try:
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')
    except Exception as e:
        logger.error(f"이미지 인코딩 오류: {e}")
        raise


@tool
def analyze_travel_image(image_path: str) -> str:
    """
    여행 사진을 분석하여 장소, 랜드마크, 분위기 등을 추론합니다.
    
    Args:
        image_path: 분석할 이미지 파일 경로
    
    Returns:
        이미지 분석 결과 문자열 (JSON 형태)
    
    Example:
        analyze_travel_image("/path/to/image.jpg")
    """
    try:
        logger.info(f"이미지 분석 시작: {image_path}")
        
        # 이미지 파일 존재 확인
        if not Path(image_path).exists():
            error_msg = f"이미지 파일을 찾을 수 없습니다: {image_path}"
            logger.error(error_msg)
            return error_msg
        
        # 이미지 base64 인코딩
        base64_image = encode_image(image_path)
        
        # 프롬프트 구성
        prompt = """이 이미지를 분석하여 다음 정보를 추출해주세요:
1. 장소/랜드마크 이름 (알 수 있는 경우)
2. 위치 추정 (나라, 도시, 지역)
3. 장소 유형 (해변, 산, 박물관, 레스토랑, 거리 등)
4. 분위기/특징 (조용한, 활기찬, 자연, 도시 등)
5. 여행 활동 추천 (이 장소에서 할 수 있는 활동)

JSON 형식으로 답변해주세요:
{
    "place_name": "장소명 또는 추정",
    "location": "추정 위치",
    "place_type": "장소 유형",
    "atmosphere": "분위기",
    "recommended_activities": ["활동1", "활동2"]
}"""
        
        # Gemini API 호출 (멀티모달) - HumanMessage 사용
        message = HumanMessage(
            content=[
                {"type": "text", "text": prompt},
                {
                    "type": "image_url",
                    "image_url": f"data:image/jpeg;base64,{base64_image}"
                }
            ]
        )
        
        llm = _get_llm()
        response = llm.invoke([message])
        
        result = response.content if hasattr(response, 'content') else str(response)
        logger.info("이미지 분석 완료")
        return result
        
    except Exception as e:
        error_msg = f"이미지 분석 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool
def extract_location_from_image(image_path: str) -> str:
    """
    이미지에서 위치 정보만 간단히 추출합니다.
    
    Args:
        image_path: 분석할 이미지 파일 경로
    
    Returns:
        위치 정보 문자열
    """
    try:
        logger.info(f"위치 정보 추출: {image_path}")
        
        if not Path(image_path).exists():
            return "이미지 파일을 찾을 수 없습니다."
        
        # 이미지 base64 인코딩
        base64_image = encode_image(image_path)
        
        prompt = "이 이미지에서 보이는 장소의 위치(나라, 도시, 지역)를 추정해주세요. 알 수 없는 경우 '미확인'이라고 답변하세요."
        
        # Gemini API 호출 (멀티모달) - HumanMessage 사용
        message = HumanMessage(
            content=[
                {"type": "text", "text": prompt},
                {
                    "type": "image_url",
                    "image_url": f"data:image/jpeg;base64,{base64_image}"
                }
            ]
        )
        
        llm = _get_llm()
        response = llm.invoke([message])
        
        location = (response.content if hasattr(response, 'content') else str(response)).strip()
        logger.info(f"추출된 위치: {location}")
        return location
        
    except Exception as e:
        error_msg = f"위치 추출 오류: {str(e)}"
        logger.error(error_msg)
        return error_msg

